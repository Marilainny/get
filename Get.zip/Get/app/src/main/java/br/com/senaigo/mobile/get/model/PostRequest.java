package br.com.senaigo.mobile.get.model;

import java.io.InputStream;
import java.util.concurrent.Callable;

public class PostRequest implements Callable<InputStream>{
    @Override
    public InputStream call() throws Exception {
        return null;
    }
}
